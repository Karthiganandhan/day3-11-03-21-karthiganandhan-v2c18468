

import java.util.Scanner;
import java.lang.String;

public class Stringcal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		    try (Scanner reader = new Scanner(System.in)) {
				System.out.print("Enter two numbers: ");

				String first = reader.nextLine();
				String second = reader.nextLine();

				System.out.print("Enter an operator (+, -, *, /): ");
				String operator = reader.next();

				String result;

				switch (operator) {
				  case "add":
				    result = first + second;
				    break;

				  case "sub":
				    result = first - second;
				    break;

				  case "mul":
				    result = first * second;
				    break;

				  case "div":
				    result = first / second;
				    break;
				    default:
				    System.out.printf("Error! operator is not correct");
				    return;
				}

				System.out.println(first + " " + operator + " " + second + " = " + result);
			}
		  }
		
		
		
	

}
