import java.math.BigDecimal;

public class Bigdecimalex    
{      
    public static void main(String[] args)     
    {      
         
        BigDecimal V1, V2;     
        
        int integerValue1, integerValue2;      
      
              
        V1 = new BigDecimal("-8799");   
        V2 = new BigDecimal("89665");  
      
           
        integerValue1 = V1.intValue();      
        integerValue2=V2.intValueExact();  
      
              
        System.out.println( "Returned int value is = "+integerValue1);  
         
        System.out.println("Returned Exact Integer Value of " +V2 + " is = " + integerValue2);   
    }      
}    