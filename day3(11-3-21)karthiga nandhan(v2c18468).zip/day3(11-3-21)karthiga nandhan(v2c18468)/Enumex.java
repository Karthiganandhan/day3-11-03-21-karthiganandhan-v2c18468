class Enumex{  
enum SSLC{   
TAMIL(5), ENGLISH(10), SCIENCE(15), SOCIAL(20);   
  
private int value;  
private SSLC(int value){  
this.value=value;  
}  
}  
public static void main(String args[]){  
for (SSLC s : SSLC.values())  
System.out.println(s+" "+s.value);  
  
}}  