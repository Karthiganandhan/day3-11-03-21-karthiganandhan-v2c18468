class Local{  private int data=7;  
 void display(){  
  int value=90;
  class Local1{  
   void msg()   {	   System.out.println(value);	   System.out.println(data);   }  
  }  
  Local1 l=new Local1();  
  l.msg();  
 }  
 public static void main(String args[]){  
  Local obj=new Local();  
  obj.display();  
 }  
}  