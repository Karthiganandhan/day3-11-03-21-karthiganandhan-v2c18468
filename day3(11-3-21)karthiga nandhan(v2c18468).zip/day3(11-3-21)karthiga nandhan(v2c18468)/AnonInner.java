abstract class k{  
  abstract void b();  
}  
class AnonInner
{  
 public static void main(String args[])
 {  
  k p=new k()
  {  
  void b(){System.out.println("hello");
  }  
  };  
  p.b();  
 }  
}  